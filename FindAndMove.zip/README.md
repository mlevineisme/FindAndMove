FindAndMove
===========

This was created to be a tool to find and copy .rb and .xml files (from the .conf file) recursively stored in a specified directory to a single directory. The .conf file must contain file names without extension, which will then be added by the script. 

You may need to modify this for your own purposes, specifically the extensions_to_move, source_folder, and DESTINATION_FOLDER parameters. 
